# Faca um algoritmo utilizando o comando while que mostra uma contagem regressiva
# na tela, iniciando em 10 e terminando em 0. Mostrar uma mensagem “FIM!” apos a
# contagem.



x = 10
while x >= 0:
    print(x)
    x = x - 1
print("FIM!")