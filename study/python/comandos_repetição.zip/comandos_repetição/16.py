# Fac ̧ a um programa que leia um n  ́umero inteiro positivo  ́ımpar N e imprima todos os
# n  ́umeros  ́ımpares de 1 ate N em ordem decrescente


v = []
n = int(input("Digite o valor de n: "))
if n -1 < 0:
    print('numero inválido')
count = 0
for num in range(1, n):
    if num % 2 != 0:
        v.append(num)
        v.sort()
        v.reverse()
print(v)
    