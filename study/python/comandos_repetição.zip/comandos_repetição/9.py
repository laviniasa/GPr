# Faca um programa que leia um numero inteiro N e depois imprima os N primeiros
# numeros naturais ımpares

x = int(input('digite um numero: '))

i = 1
n = 1

while n <= x:
    print(n)
    n += 2
