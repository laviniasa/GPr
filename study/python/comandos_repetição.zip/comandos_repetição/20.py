# Ler uma sequ ˆencia de n  ́umeros inteiros
# e determinar se eles s  ̃ao pares ou n  ̃ao.
# Devera ser informado o numero de dados lidos e numero de valores pares. 
# O processo termina
# quando for digitado o n  ́umero 100


par = []
v = []
for i in range(4):
    result = input('digite um valor: ')
    if result == 100:
        break
    v.append(result)
for num in v:
    if (num % 2) == 0:
        par.append(result)
        print('é par')
    else:
        print('não é par')
print(len(v))
print(len(par))