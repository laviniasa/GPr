# Faca um programa que calcule e mostre a soma dos 50 primeiros numeros pares

# soma = 0 
# count = 0
 
# while count < 50:
#     count += 1
#     soma += count * 2
# print(soma)

pares = []
count = 0
soma = 0
for num in range(0,5):
    if num % 2 == 0:
        pares.append(num)
for n in pares:
    count += 1
    soma += count * 2
print(soma)

        