# 2. Escreva um programa que escreva na tela, de 1 ate 100, de 1 em 1, 2 vezes. A primeira
# vez deve usar a estrutura de repeticao for e a segunda while.

for num in range(1,100):
    print(num)


# n = 100
# num = []
# for i in range (0, n+1):
#         num.append(i)
# print (num)

# x = []
# n = 100
# count = 0
# while count != n:
#     count = count + 1
#     x.append(count)
# print(x)
