# Escreva um programa que declare um inteiro, inicialize-o com 0, e incremente-o de 1000
# em 1000, imprimindo seu valor na tela, ate que seu valor seja 100.000 (cem mil)
1
for val in range(0,1000,1000000):
    print(val)
