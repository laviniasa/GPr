# Faca um programa que leia um numero inteiro positivo N e imprima todos os numeros
# naturais de 0 ate N em ordem crescente.

n = int(input('digite um valor: '))

for num in range(0, n):
    print(num)
        